#!/bin/bash
# 使用 Docker Compose 停止 mLLMCelltype Web 应用 (macOS/Linux)

echo "停止 mLLMCelltype Web 应用..."
docker-compose down

echo "应用已停止。"
