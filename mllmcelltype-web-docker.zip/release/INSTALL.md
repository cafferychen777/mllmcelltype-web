# mLLMCelltype Web 快速安装指南

本指南将帮助您快速设置和运行 mLLMCelltype Web 应用。

## 前提条件

1. 安装 Docker：
   - Windows/Mac: [Docker Desktop](https://www.docker.com/products/docker-desktop)
   - Linux: [Docker Engine](https://docs.docker.com/engine/install/)

2. 准备至少一个 LLM API 密钥：
   - [OpenAI](https://platform.openai.com/account/api-keys)
   - [Anthropic](https://console.anthropic.com/account/keys)
   - [Google Gemini](https://ai.google.dev/)
   - [X.AI Grok](https://x.ai/)

## 快速启动

### Windows 用户

1. 双击 `start.bat` 文件
2. 根据提示输入您的 API 密钥
3. 在浏览器中访问：http://localhost:8080

### macOS/Linux 用户

1. 打开终端，进入解压目录
2. 执行以下命令：
   ```bash
   chmod +x start.sh
   ./start.sh
   ```
3. 根据提示输入您的 API 密钥
4. 在浏览器中访问：http://localhost:8080

## 停止应用

### Windows 用户

双击 `stop.bat` 文件

### macOS/Linux 用户

```bash
chmod +x stop.sh
./stop.sh
```

## 详细文档

更详细的使用说明，请参阅 `README_DOCKER.md` 文件。
